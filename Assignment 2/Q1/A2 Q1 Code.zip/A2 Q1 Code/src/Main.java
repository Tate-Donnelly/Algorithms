import java.util.Arrays;
import java.util.Random;
import java.util.Stack;
import java.util.stream.IntStream;

public class Main {
    public static void main(String[] args){
        int bound=2021;
        int limit=20;
        int[] A = IntStream.generate( ()
                -> new Random().nextInt(bound)).limit(limit).toArray();

        Integer[] Ai = Arrays.stream( A ).boxed().toArray( Integer[]::new );
        Integer[] Bi = Ai.clone();

        // Priority Queue
        MaxPQ<Integer> max = new MaxPQ<Integer>(Ai.length+1);
        MinPQ<Integer> min = new MinPQ<Integer>(Bi.length+1);

        // add
        for (Integer i : Ai){
            max.insert(i);
            min.insert(i);
        }

        // tmp stacks to take all the values
        Stack<Integer> maxStack = new Stack<Integer>();
        Stack<Integer> minStack = new Stack<Integer>();

        // add all max to stack
        while (!max.isEmpty()){
            maxStack.push(max.delMax());
        }

        while (!min.isEmpty()){
            minStack.push(min.delMin());
        }

        // show result
        System.out.println("Max");
        for (Integer i : maxStack)
            System.out.print(i + " ");
        System.out.println();
        System.out.println("Min");
        for (Integer i : minStack)
            System.out.print(i + " ");
        System.out.println();
        System.out.println();

        int[] year = IntStream.generate( ()
                -> new Random().nextInt(bound)).limit(limit).toArray();
        int[] month = IntStream.generate( ()
                -> new Random().nextInt(11)).limit(limit).toArray();
        int[] day = IntStream.generate( ()
                -> new Random().nextInt(28)).limit(limit).toArray();
        Date[] dateAi=new Date[limit];

        System.out.println("Original Array: ");
        for(int i=0; i<limit; i++){
            dateAi[i]=new Date(month[i]+1, day[i]+1, year[i]);
            dateAi[i].toString();
            System.out.print(dateAi[i].toString() + " ");
        }
        System.out.println();

        Date[] dateBi = dateAi.clone();
        // Priority Queue
        MaxPQ<Date> maxDatePQ = new MaxPQ<Date>(dateAi.length+1);
        MinPQ<Date> minDatePQ = new MinPQ<Date>(dateBi.length+1);

        // add
        for (Date i : dateAi){
            maxDatePQ.insert(i);
            minDatePQ.insert(i);
        }

        Stack<Date> maxDate = new Stack<Date>();
        Stack<Date> minDate = new Stack<Date>();

        // add all max to stack
        while (!maxDatePQ.isEmpty()){
            maxDate.push(maxDatePQ.delMax());
        }

        while (!minDatePQ.isEmpty()){
            minDate.push(minDatePQ.delMin());
        }

        System.out.println("Max Date");
        for (Date i : maxDate) {
            System.out.print(i.toString() + " ");
        }
        System.out.println();
        System.out.println("Min Date");
        for (Date i : minDate) {
            System.out.print(i.toString() + " ");
        }
        System.out.println();
    }
}
