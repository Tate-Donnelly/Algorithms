public class Date implements Comparable<Date>{
    private final int month;
    private final int day;
    private final int year;

    public Date(int month, int day, int year){
        this.month=month;
        this.day=day;
        this.year=year;
    }

    //Compares the dates
    public int compareTo(Date date){
        if(this.year > date.year){
            return +1;
        }else if(this.year < date.year){
            return -1;
        }else if(this.month > date.month){
            return +1;
        }else if(this.month < date.month){
            return -1;
        }else if(this.day > date.day){
            return +1;
        }else{
            return -1;
        }
    }

    public String toString(){
        return month + "/"+ day+"/"+year;
    }
}
