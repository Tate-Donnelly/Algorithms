import java.util.Arrays;
import java.util.Random;
import java.util.stream.IntStream;

public class Main {
    public static void main(String[] args){
       int limit=250000;
       int[] allowlist = IntStream.generate(() ->
                new Random().nextInt(limit)).limit(limit).toArray();

        Integer[] allowlistInteger = Arrays.stream( allowlist ).boxed().toArray( Integer[]::new );
        Integer[] allowlistIntegerQS = allowlistInteger.clone();
        Integer[] allowlistIntegerIS = allowlistInteger.clone();

        //Adds 0 to the beginning of the HeapSorted array
        allowlistInteger = HeapSort.add2BeginningOfArray(allowlistInteger, 0);

        // QuickSort time
        Stopwatch timer3 = new Stopwatch();
        QuickSort.sort(allowlistIntegerQS);
        double time3 = timer3.elapsedTime();
        System.out.println("QuickSort " + time3);
        System.out.println("Is sorted? " + QuickSort.isSorted(allowlistIntegerQS));

		// InsertionSort time
        Stopwatch timer2 = new Stopwatch();
        InsertionSort.sort(allowlistIntegerIS);
        double time2 = timer2.elapsedTime();
        System.out.println("InsertionSort " + time2);
        System.out.println("Is sorted? " + InsertionSort.isSorted(allowlistIntegerIS));

       // HeapSorted time
       Stopwatch timer1 = new Stopwatch();
       HeapSort.sort(allowlistInteger);
       double time1 = timer1.elapsedTime();
       System.out.println("HeapSort " + time1);
       System.out.println("Is sorted? " + HeapSort.isSorted(allowlistInteger));
    }
}
