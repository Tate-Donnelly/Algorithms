import java.util.Scanner;
import java.util.Stack;

public class StackCalc {
    /**
     *
     * @param input
     * @return
     */
    public Double stackCalc(Scanner input){
        String[] output = (input.nextLine()).split(" ");
        Double result =0.0;
        Stack<String> ops = new Stack<String>();
        Stack<Double> vals = new Stack<Double>();
        int i=0;
        while (i< output.length)
        { // Read token, push if operator.

            if (output[i].equals("(")) ;
            else if (output[i].equals("+"))
            {
                ops.push(output[i]);
            }
            else if (output[i].equals("-"))
            {
                ops.push(output[i]);
            }
            else if (output[i].equals("*"))
            {
                ops.push(output[i]);
            }
            else if (output[i].equals("/"))
            {
                ops.push(output[i]);
            }
            else if (output[i].equals("sqrt"))
            {
                ops.push(output[i]);
            }
            else if (output[i].equals("pow"))
            {
                ops.push(output[i]);
            }
            else if (output[i].equals("%"))
            {
                ops.push(output[i]);
            }
            else if (output[i].equals(")"))
            {
                // Pop, evaluate, and push result if token is ")".
                String op = ops.pop();
                double v = vals.pop();
                if (op.equals("+"))
                {
                    v = vals.pop() + v;
                }
                else if (op.equals("-"))
                {
                    v = vals.pop() - v;
                }
                else if (op.equals("*"))
                {
                    v = vals.pop() * v;
                }
                else if (op.equals("/"))
                {
                    v = vals.pop() / v;
                }
                else if (op.equals("sqrt"))
                {
                    v = Math.sqrt(v);
                }
                else if (op.equals("pow"))
                {
                    v = Math.pow(vals.pop(), v);
                }
                else if (op.equals("%"))
                {
                    v = vals.pop() % v;
                }

                vals.push(v);
            } // Token not operator or parent: push double value.
            else if(!isNum(output[i]))
            {
                return 0.0;
            }
            else{
                vals.push(Double.parseDouble(output[i]));
            }
            i++;
        }
        System.out.println(" ");
        result = vals.pop();
        System.out.println(result);
        return result;
    }
    public boolean isNum(String output)
    {
        try{
            Double.parseDouble(output);
            return true;
        } catch(NumberFormatException e){
            return false;
        }

    }
}
