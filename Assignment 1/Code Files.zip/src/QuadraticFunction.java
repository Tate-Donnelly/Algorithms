public class QuadraticFunction {
    int sum=0;
    public void quadraticFunction(int[] n){
        for(int i=0;i<=n.length;i++){
            for(int j=0;j<=n.length;j++){
                sum+=j;
            }
        }
    }
}
