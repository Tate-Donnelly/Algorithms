public class Quicksort {
    public int[] quickSort(int[] a){
        sort(a, 0, a.length-1);
        return a;
    }
    public void sort(int[] a, int lo, int hi){
        if(lo<hi){
            int parIndex= partition(a, lo, hi);
            sort(a, lo, parIndex-1); //Sort left
            sort(a, parIndex+1, hi); //Sort right
        }

    }
    public int partition(int[] array, int lo, int hi){
        int parIndex = array[hi]; // partitioning item
        int i = (lo -1);
        for(int j = lo; j <= hi - 1; j++)
        {
            if (parIndex>array[j])
            {
                i++;
                exchange(array, i, j);
            }
        }
        exchange(array, i + 1, hi);
        return (i + 1);
    }
    void exchange(int[] array, int i, int j){
        int temp=array[i];
        array[i]=array[j];
        array[j]=temp;
   }

}

