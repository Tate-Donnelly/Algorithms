public class Mergesort {
    public int[] mergeSort(int[] a){
        mergeSort(a,0,a.length-1);
        return a;

    }
    private void mergeSort(int[] a, int lo, int hi){
        if(hi<=lo){
            return ;
        }
        int mid = lo + (hi - lo)/2;
        mergeSort(a,lo,mid);
        mergeSort(a,mid+1,hi);
        mergeArrays(a, lo, mid, hi);
    }

    public void mergeArrays(int[] a, int lo, int mid, int hi){
        // Find sizes of two subarrays to be merged
        int n1 = mid - lo + 1;
        int n2 = hi - mid;

        /* Create temp arrays */
        int L[] = new int[n1];
        int R[] = new int[n2];

        /*Copy data to temp arrays*/
        for (int i = 0; i < n1; ++i) {
            L[i] = a[lo + i];
        }
        for (int j = 0; j < n2; ++j) {
            R[j] = a[mid + 1 + j];
        }

        /* Merge the temp arrays */

        // Initial indexes of first and second subarrays
        int i = 0, j = 0;

        // Initial index of merged subarray array
        int k = lo;
        while (i < n1 && j < n2) {
            if (L[i] <= R[j]) {
                a[k] = L[i];
                i++;
            }
            else {
                a[k] = R[j];
                j++;
            }
            k++;
        }

        /* Copy remaining elements of L[] if any */
        while (i < n1) {
            a[k] = L[i];
            i++;
            k++;
        }

        /* Copy remaining elements of R[] if any */
        while (j < n2) {
            a[k] = R[j];
            j++;
            k++;
        }

    }
}
