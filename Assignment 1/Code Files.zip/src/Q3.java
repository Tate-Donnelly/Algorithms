import java.util.Random;
import java.util.stream.IntStream;

public class Q3 {
    public void q3(){
        LinearFunction lf=new LinearFunction();
        QuadraticFunction qf= new QuadraticFunction();
        CubicFunction cf=new CubicFunction();
        int[] n= IntStream.generate(() ->
                new Random().nextInt(100000)).limit(100000).toArray();
        Stopwatch timer1=new Stopwatch();
        lf.linearFunction(n);
        double lfT=timer1.elapsedTime();
        System.out.println("O(N): "+lfT);
        Stopwatch timer2=new Stopwatch();
        qf.quadraticFunction(n);
        double qfT=timer2.elapsedTime();
        System.out.println("O(N2): "+qfT);
        System.out.println("Printing Cubic Function time");
        Stopwatch timer3=new Stopwatch();
        cf.cubicFunction();
        double cfT=timer3.elapsedTime();
        double cfTM=cfT*100000;
        System.out.println("O(N3): "+cfTM);
        System.out.println("1 iteration: "+cfT);
    }
}
