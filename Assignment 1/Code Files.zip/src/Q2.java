import java.util.Arrays;
import java.util.Random;
import java.util.stream.IntStream;

public class Q2 {

    public void q2(int bound){
        int[] allowList = IntStream.generate(() ->
                new Random().nextInt(bound)).limit(bound).toArray();

        Arrays.sort(allowList);
        LinearFunction LS=new LinearFunction();

        int[] candidates = IntStream.generate(() ->
                new Random().nextInt(bound)).limit(1).toArray();
        System.out.println(candidates[0]);
        if( LinearSearch.linearSearch(candidates[0], allowList) == -1 )
        {
            //System.out.format("int %d not found\n", i);
        }
        else
        {
            //System.out.format("int %d found!!!\n", i);
        }



        if( BinarySearch.binarySearch(candidates[0], allowList) == -1 )
        {
            //System.out.format( "int %d not found\n", i ) ;
        }
        else
        {
            //System.out.format( "int %d found!!!\n", i ) ;
        }



        int hi = allowList.length -1;
        if( BinaryRecursion.binaryRecursion(candidates[0], allowList) == -1 )
        {
            //System.out.format( "int %d not found\n", i ) ;
        }
        else
        {
           // System.out.format( "int %d found!!!\n", i ) ;
        }


	    System.out.format( "Steps %d in Linear Search\n", LinearSearch.steps ) ;
        System.out.format( "Steps %d in Binary Search\n", BinarySearch.steps ) ;
        System.out.format( "Steps %d in Binary Recursion\n", BinaryRecursion.steps ) ;
    }
}
