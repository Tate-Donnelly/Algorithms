import java.util.Random;
import java.util.stream.IntStream;

public class Q5 {
    public void q5(int bound){
        System.out.println(bound+" ms");

        System.out.println("\nBubble Sort");
        Bubblesort bs=new Bubblesort();
        int a[]= IntStream.generate(() ->
                new Random().nextInt(bound)).limit(bound).toArray();
        Stopwatch timer1=new Stopwatch();
        int[] tempBS=bs.bubbleSort(a);
        double elapsedTime1=timer1.elapsedTime();
        System.out.println("Bubble Sort time = "+elapsedTime1);

        System.out.println("\nMerge Sort");
        Mergesort ms= new Mergesort();
        int b[]= IntStream.generate(() ->
                new Random().nextInt(bound)).limit(bound).toArray();
        Stopwatch timer2=new Stopwatch();
        int[] tempMS=ms.mergeSort(b);
        double elapsedTime2=timer2.elapsedTime();
        System.out.println("Merge Sort time = "+elapsedTime2);

        System.out.println("\nQuick Sort");
        Quicksort qs= new Quicksort();
        int c[]= IntStream.generate(() ->
                new Random().nextInt(bound)).limit(bound).toArray();
        Stopwatch timer3=new Stopwatch();
        int[] tempQS=qs.quickSort(c);
        double elapsedTime3=timer3.elapsedTime();
        System.out.println("Quick Sort time = "+elapsedTime3);
    }
}
