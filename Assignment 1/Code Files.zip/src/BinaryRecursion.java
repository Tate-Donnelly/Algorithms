public class BinaryRecursion {
    public static int steps = 0;

    public static int binaryRecursion(int key, int[] a) {

        return binaryRecursion(key, a, 0, a.length - 1);
    }

    public static int binaryRecursion(int key, int[] a,  int lo, int hi) {
        steps++; //Step counter is placed here as it will allow the program to count every element that the function looks at
        if(hi < lo){
            return -1;
        }
        int mid = lo + (hi - lo) / 2;
         if (key < a[mid])
         {
            hi = mid - 1;
            binaryRecursion(key,a,lo, mid - 1);
         }
        else if (key > a[mid])
        {
            lo = mid + 1;
            binaryRecursion(key,a,mid + 1, hi);
        }
        else{
            return mid;
        }
        return 0;
    }
}
