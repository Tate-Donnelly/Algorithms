public class LinearFunction {
    int sum=0;
    public void linearFunction(int[] n){
        for(int i=0;i<=n.length;i++){
            sum+=i;
        }
    }
}
