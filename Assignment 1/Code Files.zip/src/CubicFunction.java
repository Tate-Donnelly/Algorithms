public class CubicFunction {
    int sum=0;
    int n=100000;
    public void cubicFunction(){
        for(int i=0;i<=n;i++){
            for(int j=0;j<=n;j++){
                for(int k=0;k<=n;k++){
                    sum+=k;
                }
            }
            break;
        }
    }
}
