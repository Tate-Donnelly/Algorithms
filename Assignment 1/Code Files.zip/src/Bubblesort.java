public class Bubblesort {
    public int[] bubbleSort(int[] a){
        for (int loop = 0; loop < a.length-1; loop++) {
            for (int ele = 0; ele < a.length - 1 - loop; ele++) {
                if (a[ele] > a[ele + 1]) {
                    int temp = a[ele];
                    a[ele] = a[ele + 1];
                    a[ele + 1] = temp;
                }
            }
        }
        return a;
    }
}
