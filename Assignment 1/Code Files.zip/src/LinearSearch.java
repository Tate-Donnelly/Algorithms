public class LinearSearch {
    public static int steps = 0;


    public static int linearSearch(int key, int[] a) {

        for(int i = 0; i < a.length; i++) {
            steps++; //Step counter is placed here as it will allow the program to count every element that the function looks at
            if(a[i] == key) {
                return i;
            }
        }
        return -1;
    }
}
