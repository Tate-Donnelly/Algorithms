import java.util.Random;
import java.util.Scanner;
import java.util.Stack;
import java.util.stream.IntStream;


public class Main {
    public static void main(String[] args){
        StackCalc sc=new StackCalc();
        Q2 question2=new Q2();
        Q1 question1 = new Q1();
        Q3 question3=new Q3();
        Q5 question5=new Q5();
        int bound=250000;

        question1.q1();
        question2.q2(bound);
        question3.q3();
        question5.q5(bound);
    }
}
