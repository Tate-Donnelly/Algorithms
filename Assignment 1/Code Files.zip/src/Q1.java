import java.util.Random;
import java.util.Scanner;
import java.util.stream.IntStream;

public class Q1 {
    StackCalc sc = new StackCalc();
    public void q1(){
        boolean Q1 = testWorkingExpression1() && testWorkingExpression2() && testWorkingExpression3() && testFailedExpression() && testPowExpression() && testModExpression();
    }
    //Tests an expression that should succeed
    public boolean testWorkingExpression1(){
        boolean result= false;
        Scanner scan = new Scanner("( 1 + ( ( 2 + 3 ) * ( 4 * 5 ) ) )");
        Double num = sc.stackCalc(scan);
        if(num==101.0){
            System.out.println("Working Expression 1 works!!!");
            result=true;
        }else{
            System.out.println("Working Expression 1 failed!!!");
        }
        return result;
    }
    //Tests an expression that should succeed
    public boolean testWorkingExpression2(){
        boolean result= false;
        Scanner scan = new Scanner("( ( 1 + sqrt ( 5.0 ) ) / 2.0 )");
        Double num = sc.stackCalc(scan);
        if(num==1.618033988749895){
            System.out.println("Working Expression 2 works!!!");
            result=true;
        }else{
            System.out.println("Working Expression 2 failed!!!");
        }
        return result;
    }
    //Tests an expression that should succeed
    public boolean testWorkingExpression3(){
        boolean result= false;
        Scanner scan = new Scanner("( ( 4 + 1 ) + 3 )");
        Double num = sc.stackCalc(scan);
        if(num==8){
            System.out.println("Working Expression 3 works!!!");
            result=true;
        }else{
            System.out.println("Working Expression 3 failed!!!");
        }
        return result;
    }
    //Tests an equation that should fail
    public boolean testFailedExpression(){
        boolean result= false;
        Scanner scan = new Scanner("( 1 + 1 - 2 )");
        Double num = 0.0;
        num = sc.stackCalc(scan);
        if(num!=0.0){
            System.out.println("Failed Expression failed!!!");
            result=true;
        }else{
            System.out.println("Failed Expression works!!!");
        }
        return result;
    }
    //Tests the new power operator
    public boolean testPowExpression(){
        boolean result= false;
        Scanner scan = new Scanner("( 3 pow 2 )");
        Double num = sc.stackCalc(scan);
        if(num==9.0){
            System.out.println("Pow Expression works!!!");
            result=true;
        }else{
            System.out.println("Pow Expression failed!!!");
        }
        return result;
    }
    //Tests the new modulo operator
    public boolean testModExpression(){
        boolean result= false;
        Scanner scan = new Scanner("( 3 % 2 )");
        Double num = sc.stackCalc(scan);
        if(num==1.0){
            System.out.println("Mod Expression works!!!");
            result=true;
        }else{
            System.out.println("Mod Expression failed!!!");
        }
        return result;
    }




}
